package com.example.AdvancedDataStructure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;


@Controller
@SpringBootApplication
public class WebApplication {
    private Trie trie = new Trie();

    public static void main(String[] args) {
        SpringApplication.run(WebApplication.class, args);
    }

    @GetMapping("/")
    public String index() {
        return "index"; // This should match the name of your HTML template (index.html)
    }

    @PostMapping("/add")
    public String addText(@RequestParam("text") String text) {
        // Split the input text into words and insert into the Trie
        String[] words = text.split("\\s+");
        for (String word : words) {
            trie.insert(word);
        }
        return "redirect:/"; // Redirect to the root URL after adding text
    }

    @GetMapping("/search")
    public String searchWord(@RequestParam("word") String word, Model model) {
    	int count = trie.search(word);
        model.addAttribute("count", count);
        return "index";// This should match the name of your HTML template (index.html)
    }
}

